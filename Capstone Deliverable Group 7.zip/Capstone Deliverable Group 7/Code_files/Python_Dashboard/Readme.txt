This Dashboard is hosted live on https://live-epilepsy-funding-research-dashboard.onrender.com/


For more details visit my GitHub page https://github.com/Nihar-Shah-26/Epilepsy_Funding_research_funding_dashboard 